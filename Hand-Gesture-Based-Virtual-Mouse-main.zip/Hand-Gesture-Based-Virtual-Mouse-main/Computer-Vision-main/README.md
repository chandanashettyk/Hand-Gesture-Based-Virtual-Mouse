Watch tutorials explaning all these projects:
https://www.youtube.com/@dsbrain
